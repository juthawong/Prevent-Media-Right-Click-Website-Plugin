jQuery(document).ready(function() {
    jQuery("img").on("contextmenu",function(){
       return false;
    }); 
    jQuery("video").on("contextmenu",function(){
       return false;
    }); 
    jQuery("audio").on("contextmenu",function(){
       return false;
    }); 
}); 
